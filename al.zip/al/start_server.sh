#!/bin/bash
echo "============================================"
echo "  会声 HuiSheng — 本地启动脚本 (macOS/Linux)"
echo "============================================"
echo ""

# 检查 Node.js
if ! command -v node &> /dev/null; then
    echo "[错误] 未找到 Node.js，请先安装：https://nodejs.org"
    exit 1
fi

# 如果已设置环境变量，直接启动
if [ -n "$DASHSCOPE_API_KEY" ]; then
    echo "[✓] 已检测到 DASHSCOPE_API_KEY 环境变量"
else
    echo "请输入你的百炼 API Key（获取地址：https://bailian.console.aliyun.com）"
    echo "如果暂时没有，直接回车跳过（将使用模拟数据模式）"
    echo ""
    read -p "API Key: " USER_KEY
    if [ -n "$USER_KEY" ]; then
        export DASHSCOPE_API_KEY="$USER_KEY"
        echo "[✓] API Key 已设置（仅本次有效）"
    else
        echo "[!] 未设置 API Key，将以模拟模式运行"
    fi
fi

echo ""
echo "[启动中] node server.js ..."
echo "[提示] 打开浏览器访问 http://localhost:8000"
echo "[提示] 按 Ctrl+C 停止服务"
echo ""
node server.js
