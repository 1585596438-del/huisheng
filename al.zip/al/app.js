// ============================================================
// 「会声」HuiSheng — app.js  v2.0
// 四大功能：会议分析 / 周报生成 / 需求对齐 / 行动项看板
// ============================================================

// ──────────────────────────────────────────────
// Demo 数据
// ──────────────────────────────────────────────
const rawImperfectTranscript = `
那个大家上午好啊听得到我说话吗喂喂好的听得到挺清楚的好那我们就开始了今天这个会呢主要是那个对齐一下咱们会声这个产品的MVP版本的那个核心功能还有发布节奏就是那个目前的ASR模块就是那个语音转文字那个已经接进来了但是在那个高噪音环境下那个识别率就是那个准头儿还有提升空间大家明白吧是的张总关于那个ASR我这边的计划是就是那个下周二之前通过接入那个智谱AI的语音分析API来优化一下就是那个目前的那个主要分歧点在于咱们是不是要在MVP版本里面把那个周报自动生成的功能给塞进去那个我插一句啊我王芳建议还是得包含因为这个是咱们跟别家不一样的卖点前端这边呢大概需要3天时间就是那个模版渲染啥的只要后端接口能给那个结构化的JSON就是那种规规矩矩的数据我这边就没问题嗯那个我想想同意王芳说的那李华后端那个周报接口能不能在那个下周四之前出个Mock就是那个假数据接口那个没问题周三晚上就能出好那咱们就这么定了达成一致了啊第一MVP版本包含周报功能第二李华负责下周二之前把ASR优化好然后在周三把周报Mock接口给出来第三王芳负责在下周五之前把前端模版渲染和导出功能搞定明白了那个我会优先处理那个CSV和Markdown的导出好那个下周五下午4点咱们准时内部Demo今天就先这样散会散会
`.trim();

const englishDemoTranscript = `
Alright can everyone hear me okay good uh let's go ahead and get started we've got a lot to cover today so um the main thing we need to sort out is the Q2 product roadmap and specifically what's going in and what's getting pushed so Sarah you wanna kick us off yeah sure um so basically right now we've got three things in flight the onboarding redesign the notifications overhaul and the API rate limiting work and honestly I think we need to make a call today on which one we're actually gonna ship before the end of quarter because we can't do all three well right and that's the thing like I totally agree we've been spreading too thin um Jake what's the status on notifications so uh we're about sixty percent done the backend logic is solid but the front end still needs work I'd say we need like two more weeks minimum maybe three if we hit any more issues with the push service okay so realistically that's end of May which is cutting it close what about onboarding David yeah onboarding we're in better shape honestly we could have something shippable by May 15th we still have some edge cases to handle around the team invite flow but nothing blocking okay so my take is we prioritize onboarding for Q2 and we push notifications to Q3 does anyone strongly disagree I mean I'm not gonna fight it but I do think notifications has higher user impact based on the support tickets we've been seeing yeah no I hear you Sarah but I think the onboarding drop-off is hurting us more in terms of activation metrics and that's a direct revenue impact fair enough okay so let's call it onboarding is the Q2 priority Jake can you get notifications scoped for Q3 planning by next Friday yeah I can do that I'll have a rough scope doc by Thursday actually perfect and David let's sync tomorrow on the May 15th timeline and figure out what we need to cut from scope to hit that date sounds good I'll send a calendar invite this afternoon great anything else before we wrap up um one quick thing the design team needs sign-off on the new component library by end of week otherwise it blocks the engineering work next sprint that's on me I'll review it today and get back to Marcus by EOD cool alright we're good thanks everyone talk soon
`.trim();

const longMeetingDemoTranscript = `
喂喂大家能听到吗李华你那边麦克风好像有点杂音哦不好意思我调一下现在好点了吗刚才在试那个降噪插件挺清楚的赵强还没进来吗来了来了刚才那个电梯等了好久不好意思啊各位没事那咱就开始吧今天这会稍微长点咱们要把Q3的整个产品路线图Roadmap给敲死首先说一下咱们的核心卖点就是那个长会议分析说到这个我赵强多句嘴啊昨天我见了一家大客户他们特别强调说现在的会议动辄两个小时转出来的文字几万字全是废话他们最头疼的就是怎么从这堆垃圾里翻出有用的东西对这正是咱们要解决的李华智谱GLM-4的长文本窗口现在能吃多少那个GLM-4现在的context window很大理论上处理10万字都没问题但我测试发现如果一次性塞两万字以上它有时候会幻觉或者漏掉中间的一些小决策所以我打算在后端做一个分段提取加全局聚合的策略分段提取的话前端展示怎么搞是分段展示摘要吗不用户还是希望看到一个完整的全局的摘要李华你那个聚合算法一定要准明白我计划下周三之前把这个聚合逻辑调优好张明记一下采用分段提取加全局聚合策略处理超长文本负责人李华时间下周三前那个咱们是不是该点个咖啡我有点困强哥你这刚开始就困啊别贫了说正事关于周报自动生成功能王芳你那边进度咋样前端模版已经画好了现在支持Markdown和PDF导出但是有个问题如果会议里提到了很多敏感数据比如销售额咱们是不是得做个脱敏这个必须有企业客户对隐私非常敏感同意那咱们在AI提取阶段加一个隐私过滤层王芳你把这个需求加到前端的配置项里让用户可以勾选是否开启隐私脱敏好的我这周五能搞定张明记一下王芳在周五前增加隐私脱敏勾选功能所以我觉得用分布式存储更稳行架构听你的那咱们说市场推广赵强Q3的发布会定在哪天我看了下日历8月15号是个周五挺合适的咱们可以请几个科技博主来测评但是预算这块老板还没批预算我张明去找老板谈你赵强先把方案写出来周五下班前发我行没问题对了咱们那个手机App还要做吗Q3先不做App太重了咱们先做一个飞书和钉钉的微应用插件飞书插件我之前研究过接口比较友好那咱们定一下Q3优先开发飞书钉钉插件暂缓原生App开发那个我刚才点外卖你们谁要喝奶茶我随便来杯美式就行我要杨枝甘露谢了强哥咳咳继续最后对一下时间点下周五我们要出一个内部的Alpha版本包含长会议分析和周报生成大家有没有压力有点紧但我李华加班能赶出来我也没问题好那今天就到这散会
`.trim();

// ──────────────────────────────────────────────
// 语言切换
// ──────────────────────────────────────────────
let currentLanguage = 'zh';

function setLanguage(lang) {
    currentLanguage = lang;
    const zhBtn = document.getElementById('langZhBtn');
    const enBtn = document.getElementById('langEnBtn');
    
    if (lang === 'zh') {
        zhBtn.className = 'px-3 py-1.5 rounded-md text-sm font-medium transition bg-white text-blue-600 shadow-sm';
        enBtn.className = 'px-3 py-1.5 rounded-md text-sm font-medium transition text-gray-600 hover:text-blue-600';
    } else {
        enBtn.className = 'px-3 py-1.5 rounded-md text-sm font-medium transition bg-white text-blue-600 shadow-sm';
        zhBtn.className = 'px-3 py-1.5 rounded-md text-sm font-medium transition text-gray-600 hover:text-blue-600';
    }
}

// ──────────────────────────────────────────────
// Tab 切换
// ──────────────────────────────────────────────
function switchTab(id) {
    document.querySelectorAll('.tab-panel').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active-tab');
        btn.classList.add('inactive-tab');
    });
    document.getElementById(id).classList.remove('hidden');
    const btn = document.getElementById(id + '-btn');
    if (btn) { btn.classList.add('active-tab'); btn.classList.remove('inactive-tab'); }
}

// ──────────────────────────────────────────────
// 多平台 AI API 直连（阿里云百炼 / 智谱 GLM）
// ──────────────────────────────────────────────

const AI_PROVIDERS = {
    qwen: {
        name: '阿里云百炼（通义千问）',
        label: 'Qwen',
        icon: 'fa-cloud',
        color: 'orange',
        placeholder: 'sk-xxxxxxxxxxxxxxxx',
        storageKey: 'huisheng_api_key_qwen',
        models: [
            { value: 'qwen-plus', label: 'Qwen-Plus（推荐）' },
            { value: 'qwen-max', label: 'Qwen-Max（最强）' },
            { value: 'qwen-turbo', label: 'Qwen-Turbo（最快）' }
        ],
        async call(apiKey, model, systemPrompt, userPrompt) {
            const res = await fetch('https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
                body: JSON.stringify({
                    model, temperature: 0.3, max_tokens: 3000,
                    messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }]
                })
            });
            if (!res.ok) { const e = await res.json().catch(() => ({})); throw new Error((e.error && e.error.message) || 'API Error ' + res.status); }
            const d = await res.json();
            return d.choices[0].message.content;
        }
    },
    zhipu: {
        name: '智谱 AI（GLM）',
        label: 'GLM',
        icon: 'fa-robot',
        color: 'purple',
        placeholder: '智谱 API Key（从 open.bigmodel.cn 获取）',
        storageKey: 'huisheng_api_key_zhipu',
        models: [
            { value: 'glm-4-plus', label: 'GLM-4-Plus（推荐）' },
            { value: 'glm-4', label: 'GLM-4（均衡）' },
            { value: 'glm-4-flash', label: 'GLM-4-Flash（最快/免费）' },
            { value: 'glm-4-long', label: 'GLM-4-Long（超长文本）' }
        ],
        async call(apiKey, model, systemPrompt, userPrompt) {
            const res = await fetch('https://open.bigmodel.cn/api/paas/v4/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
                body: JSON.stringify({
                    model, temperature: 0.3, max_tokens: 3000,
                    messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userPrompt }]
                })
            });
            if (!res.ok) { const e = await res.json().catch(() => ({})); throw new Error((e.error && e.error.message) || 'API Error ' + res.status); }
            const d = await res.json();
            return d.choices[0].message.content;
        }
    }
};

// 当前使用的 provider
function getCurrentProvider() {
    return localStorage.getItem('huisheng_provider') || 'qwen';
}
function getCurrentModel() {
    const p = getCurrentProvider();
    const defaultModel = AI_PROVIDERS[p].models[0].value;
    return localStorage.getItem('huisheng_model_' + p) || defaultModel;
}
function getApiKey(provider) {
    const p = provider || getCurrentProvider();
    return localStorage.getItem(AI_PROVIDERS[p].storageKey) || '';
}

// 统一 AI 调用入口
async function callAI(systemPrompt, userPrompt) {
    const providerKey = getCurrentProvider();
    const provider = AI_PROVIDERS[providerKey];
    const apiKey = getApiKey(providerKey);
    if (!apiKey) {
        showApiKeyModal();
        throw new Error('请先配置 API Key');
    }
    const model = getCurrentModel();
    return provider.call(apiKey, model, systemPrompt, userPrompt);
}

// 兼容旧调用名
const callQwen = callAI;

// 统一入口，根据 endpoint 构造不同的 prompt
async function callAPI(endpoint, body) {
    let systemPrompt = '', userPrompt = '';

    if (endpoint === '/api/fix') {
        systemPrompt = '你是一个会议纪要整理专家。请将以下凌乱的 ASR 转写文本进行修正：纠正同音字错误、添加标点符号、识别并标注说话人（如果可以推断）、去除冗余语气词。保持原意不变，使文本专业、易读。直接输出修正后的文本。';
        userPrompt = body.transcript;

    } else if (endpoint === '/api/analyze') {
        systemPrompt = `你是一个专业的会议分析助手。请严格按照以下 JSON 格式输出分析结果，不要添加任何额外说明或 markdown 代码块：
{"summary":"会议核心摘要（2-3句话，突出关键结论）","decisions":["决策1","决策2","决策3"],"actions":[{"title":"行动项内容","owner":"负责人","dueDate":"截止日期（如无则为空字符串）","priority":"P0/P1/P2/P3"},{"title":"...","owner":"...","dueDate":"...","priority":"..."}]}
要求：1.summary 简洁清晰；2.decisions 提取明确拍板的决定；3.actions 提取所有人员承诺的具体任务，priority 根据紧急重要性判断。`;
        userPrompt = body.transcript;

    } else if (endpoint === '/api/weekly') {
        const styleMap = {
            concise: '简洁专业风格，重点突出，避免废话，适合汇报给直接上级',
            detailed: '数据详实风格，尽量量化成果，适合汇报给大领导',
            team: '轻松协作风格，说清楚在哪里帮到了团队、哪里需要支持'
        };
        systemPrompt = `你是一个职场效率专家，擅长将碎片化的工作记录整理成专业的工作周报。
请根据用户提供的本周工作流水账，生成一份结构清晰的工作周报。
岗位：${body.role || '职场人'}
汇报风格：${styleMap[body.style] || styleMap.concise}

周报格式要求（严格遵守）：
【本周完成事项】
- 用 1-2 句话描述每项完成工作，突出结果和价值

【本周关键决策 / 推进项目】
- 列出重要决策和项目推进情况

【下周工作计划】
- 具体可执行的计划，3-5 条

【本周遇到的问题/风险】
- 客观描述阻碍或风险，必要时附带解决思路

请直接输出周报正文，不要加任何前言解释。`;
        userPrompt = body.input;

    } else if (endpoint === '/api/align') {
        systemPrompt = `你是一个专业的跨部门需求对齐顾问，擅长识别各方诉求的冲突点并给出务实的共识方案。
请根据用户提供的各方需求描述，生成一份结构化的需求对齐报告。

报告格式（严格遵守）：

━━━━━━━━━━━━━━━━━━━━━━
【需求对齐报告】
━━━━━━━━━━━━━━━━━━━━━━

▶ 各方核心诉求
  · 第一方：[一句话总结核心目标]
  · 第二方：[一句话总结核心目标]
  · 第三方：[一句话总结核心目标，如有]

▶ 冲突分析
  ⚠️ 冲突1：[冲突描述及根本原因]
  ⚠️ 冲突2：[如有]

▶ 共识基础
  ✅ [各方都能接受的共同点]

▶ 建议方案
  【方案A】[推荐方案，说明理由]
  【方案B】[备选方案]

▶ 下一步行动
  · [具体行动项，含负责人和时间节点]

━━━━━━━━━━━━━━━━━━━━━━

请直接输出报告内容，语言简洁务实。`;
        const parts = [];
        if (body.p1) parts.push(`第一方需求：${body.p1}`);
        if (body.p2) parts.push(`第二方需求：${body.p2}`);
        if (body.p3) parts.push(`第三方需求：${body.p3}`);
        userPrompt = parts.join('\n\n');
    }

    const resultText = await callAI(systemPrompt, userPrompt);
    return { result: resultText };
}

// 调用后端API（用于ASR和需要语言参数的功能）
async function callBackendAPI(endpoint, body) {
    const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(body)
    });
    
    if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.error || `API Error ${response.status}`);
    }
    
    return await response.json();
}

// ──────────────────────────────────────────────
// API Key 配置弹窗（多平台）
// ──────────────────────────────────────────────
function showApiKeyModal() {
    if (document.getElementById('apiKeyModal')) return;

    const currentProvider = getCurrentProvider();
    const currentModel = getCurrentModel();

    // 生成平台切换按钮 HTML
    function providerTabHTML(key, selected) {
        const p = AI_PROVIDERS[key];
        const colors = {
            qwen:  { bg: 'bg-orange-500', light: 'bg-orange-50', border: 'border-orange-200', text: 'text-orange-600' },
            zhipu: { bg: 'bg-purple-500', light: 'bg-purple-50', border: 'border-purple-200', text: 'text-purple-600' }
        };
        const c = colors[key];
        if (selected) {
            return `<button onclick="switchProviderTab('${key}')" id="ptab-${key}" class="flex-1 flex items-center justify-center space-x-2 py-2.5 rounded-xl ${c.bg} text-white text-sm font-semibold shadow-md transition">
                <i class="fas ${p.icon} text-xs"></i><span>${p.label}</span>
            </button>`;
        }
        return `<button onclick="switchProviderTab('${key}')" id="ptab-${key}" class="flex-1 flex items-center justify-center space-x-2 py-2.5 rounded-xl ${c.light} ${c.text} border ${c.border} text-sm font-semibold transition hover:shadow">
            <i class="fas ${p.icon} text-xs"></i><span>${p.label}</span>
        </button>`;
    }

    // 生成模型选项 HTML
    function modelOptionsHTML(providerKey) {
        const p = AI_PROVIDERS[providerKey];
        const savedModel = localStorage.getItem('huisheng_model_' + providerKey) || p.models[0].value;
        return p.models.map(m =>
            `<option value="${m.value}" ${m.value === savedModel ? 'selected' : ''}>${m.label}</option>`
        ).join('');
    }

    const modal = document.createElement('div');
    modal.id = 'apiKeyModal';
    modal.className = 'fixed inset-0 bg-black/60 backdrop-blur-sm z-[500] flex items-center justify-center p-4';
    modal.innerHTML = `
        <div class="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-7 space-y-5">
            <!-- 标题 -->
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="bg-blue-100 p-2.5 rounded-xl"><i class="fas fa-key text-blue-600 text-xl"></i></div>
                    <div>
                        <h3 class="text-lg font-bold text-gray-900">AI 模型配置</h3>
                        <p class="text-xs text-gray-400 mt-0.5">Key 仅保存在本地浏览器，不上传任何服务器</p>
                    </div>
                </div>
                <button onclick="document.getElementById('apiKeyModal').remove()" class="text-gray-400 hover:text-gray-600 p-1.5 rounded-lg hover:bg-gray-100 transition">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <!-- 平台切换 -->
            <div>
                <label class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 block">选择 AI 平台</label>
                <div class="flex space-x-2" id="providerTabs">
                    ${providerTabHTML('qwen', currentProvider === 'qwen')}
                    ${providerTabHTML('zhipu', currentProvider === 'zhipu')}
                </div>
            </div>

            <!-- 当前平台 Key 输入 -->
            <div id="apiKeySection">
                ${renderApiKeySection(currentProvider, currentModel)}
            </div>

            <!-- 已配置状态 -->
            <div id="configStatus" class="text-xs text-gray-400 space-y-1">
                ${renderConfigStatus()}
            </div>

            <!-- 保存按钮 -->
            <button onclick="saveApiKeyMulti()" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl text-sm font-semibold transition shadow-md">
                <i class="fas fa-check mr-2"></i> 保存配置并使用
            </button>
        </div>`;
    document.body.appendChild(modal);
    setTimeout(() => { const inp = document.getElementById('apiKeyInputMain'); if (inp) inp.focus(); }, 100);
}

function renderApiKeySection(providerKey, selectedModel) {
    const p = AI_PROVIDERS[providerKey];
    const savedKey = getApiKey(providerKey);
    const links = {
        qwen: 'https://dashscope.console.aliyun.com/apiKey',
        zhipu: 'https://open.bigmodel.cn/usercenter/apikeys'
    };
    const hints = {
        qwen: '新用户有大额免费额度，推荐首选',
        zhipu: 'GLM-4-Flash 完全免费，GLM-4-Long 支持超长文本'
    };
    const modelOpts = p.models.map(m => {
        const saved = localStorage.getItem('huisheng_model_' + providerKey) || p.models[0].value;
        return `<option value="${m.value}" ${m.value === saved ? 'selected' : ''}>${m.label}</option>`;
    }).join('');

    return `
        <div>
            <label class="text-sm font-medium text-gray-700 block mb-1.5">API Key — <span class="text-gray-400 font-normal">${p.name}</span></label>
            <input id="apiKeyInputMain" type="password" placeholder="${p.placeholder}"
                class="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono mb-2"
                value="${savedKey}">
            <div class="flex items-center justify-between text-xs text-gray-400">
                <span class="text-emerald-600">${hints[providerKey]}</span>
                <a href="${links[providerKey]}" target="_blank" class="text-blue-500 hover:underline flex items-center space-x-1">
                    <i class="fas fa-external-link-alt text-[10px]"></i><span>获取 Key</span>
                </a>
            </div>
        </div>
        <div class="mt-3">
            <label class="text-sm font-medium text-gray-700 block mb-1.5">模型选择</label>
            <select id="modelSelect" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
                ${modelOpts}
            </select>
        </div>
        <input type="hidden" id="activeProvider" value="${providerKey}">`;
}

function renderConfigStatus() {
    return Object.entries(AI_PROVIDERS).map(([key, p]) => {
        const hasKey = !!getApiKey(key);
        const isCurrent = getCurrentProvider() === key;
        const model = localStorage.getItem('huisheng_model_' + key) || p.models[0].label;
        return `<span class="inline-flex items-center space-x-1 mr-3 ${isCurrent ? 'text-blue-500 font-semibold' : ''}">
            <i class="fas fa-circle text-[6px] ${hasKey ? 'text-emerald-500' : 'text-gray-300'}"></i>
            <span>${p.label}：${hasKey ? '已配置' : '未配置'}${isCurrent ? ' ✓ 使用中' : ''}</span>
        </span>`;
    }).join('');
}

window.switchProviderTab = function(key) {
    const section = document.getElementById('apiKeySection');
    const model = localStorage.getItem('huisheng_model_' + key) || AI_PROVIDERS[key].models[0].value;
    section.innerHTML = renderApiKeySection(key, model);

    // 更新 tab 样式
    const colors = {
        qwen:  { bg: 'bg-orange-500 text-white shadow-md', off: 'bg-orange-50 text-orange-600 border border-orange-200' },
        zhipu: { bg: 'bg-purple-500 text-white shadow-md', off: 'bg-purple-50 text-purple-600 border border-purple-200' }
    };
    Object.keys(AI_PROVIDERS).forEach(k => {
        const tab = document.getElementById('ptab-' + k);
        if (!tab) return;
        const isActive = k === key;
        const c = colors[k];
        tab.className = `flex-1 flex items-center justify-center space-x-2 py-2.5 rounded-xl text-sm font-semibold transition ${isActive ? c.bg : c.off + ' hover:shadow'}`;
    });

    setTimeout(() => { const inp = document.getElementById('apiKeyInputMain'); if (inp) inp.focus(); }, 50);
};

window.saveApiKeyMulti = function() {
    const providerKey = document.getElementById('activeProvider').value;
    const keyVal = document.getElementById('apiKeyInputMain').value.trim();
    const modelVal = document.getElementById('modelSelect').value;

    if (!keyVal) { showToast('请输入有效的 API Key', 'error'); return; }

    // 保存 Key 和模型
    localStorage.setItem(AI_PROVIDERS[providerKey].storageKey, keyVal);
    localStorage.setItem('huisheng_model_' + providerKey, modelVal);
    // 切换当前使用的 provider
    localStorage.setItem('huisheng_provider', providerKey);

    document.getElementById('apiKeyModal').remove();
    updateNavApiKeyBadge();
    showToast(`已切换到 ${AI_PROVIDERS[providerKey].label} · ${modelVal} ✓`, 'success');
};

// 导航栏 API Key 按钮显示当前 provider 名
function updateNavApiKeyBadge() {
    const btn = document.getElementById('navApiKeyBtn');
    if (!btn) return;
    const p = AI_PROVIDERS[getCurrentProvider()];
    const hasKey = !!getApiKey();
    const dot = hasKey ? '<span class="w-2 h-2 rounded-full bg-emerald-400 inline-block mr-1"></span>' : '';
    btn.innerHTML = `<i class="fas fa-key text-xs"></i><span class="hidden md:inline ml-1.5">${dot}${p ? p.label : 'API Key'}</span>`;
}

// 兼容旧的 saveApiKey（防止其他地方残留调用）
window.saveApiKey = window.saveApiKeyMulti;

// ──────────────────────────────────────────────
// 1. 会议分析模块
// ──────────────────────────────────────────────
const btnQuickDemo   = document.getElementById('btnQuickDemo');
const btnRecord      = document.getElementById('btnRecord');
const btnStopRecord  = document.getElementById('btnStopRecord');
const recordingIndicator = document.getElementById('recordingIndicator');
const recordDuration = document.getElementById('recordDuration');
const audioPreviewZone = document.getElementById('audioPreviewZone');
const audioPlayback  = document.getElementById('audioPlayback');
const btnSmartFix    = document.getElementById('btnSmartFix');
const btnFillDemo    = document.getElementById('btnFillDemo');
const btnFillEnDemo  = document.getElementById('btnFillEnDemo');
const btnFillLongDemo = document.getElementById('btnFillLongDemo');
const btnAnalyze     = document.getElementById('btnAnalyze');
const transcriptInput = document.getElementById('transcriptInput');
const outputZone     = document.getElementById('outputZone');
const summaryContent = document.getElementById('summaryContent');
const decisionsList  = document.getElementById('decisionsList');
const actionsTableBody = document.getElementById('actionsTableBody');
const btnCopyMD      = document.getElementById('btnCopyMD');
const btnDownloadCSV = document.getElementById('btnDownloadCSV');
const btnSendToTracker = document.getElementById('btnSendToTracker');

const wordCountText = document.createElement('div');
wordCountText.className = 'text-[10px] text-gray-400 mt-1 text-right';
if (transcriptInput && transcriptInput.parentNode) {
    transcriptInput.parentNode.insertBefore(wordCountText, transcriptInput.nextSibling);
    transcriptInput.addEventListener('input', () => {
        wordCountText.textContent = `当前内容长度：${transcriptInput.value.length} 字 | 建议 30,000 字以内`;
    });
}

let lastAnalysisResult = null;
let mediaRecorder = null;
let audioChunks = [];
let startTime = null;
let timerInterval = null;
let recognition = null;
let accumulatedTranscript = '';

// Web Speech API
if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'zh-CN';
    recognition.onresult = (event) => {
        let interim = '', finalT = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) finalT += event.results[i][0].transcript;
            else interim += event.results[i][0].transcript;
        }
        if (finalT) accumulatedTranscript += finalT;
        transcriptInput.value = (accumulatedTranscript + interim).trim();
    };
    recognition.onerror = (e) => console.error('Speech Error:', e.error);
}

async function startRecording() {
    try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        if (!devices.some(d => d.kind === 'audioinput')) { alert('未检测到麦克风，请插入后重试。'); return; }
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        audioChunks = []; accumulatedTranscript = '';
        transcriptInput.value = ''; transcriptInput.placeholder = '正在实时识别您的语音...';
        mediaRecorder.ondataavailable = e => audioChunks.push(e.data);
        mediaRecorder.onstop = () => {
            const blob = new Blob(audioChunks, { type: 'audio/wav' });
            audioPlayback.src = URL.createObjectURL(blob);
            audioPreviewZone.classList.remove('hidden');
            if (!transcriptInput.value.trim()) transcriptInput.value = '（未检测到有效语音，请确认麦克风已授权）';
            else btnSmartFix.classList.remove('hidden');
        };
        mediaRecorder.start();
        if (recognition) { try { recognition.start(); } catch(e) {} }
        startTime = Date.now(); updateTimer();
        timerInterval = setInterval(updateTimer, 1000);
        recordingIndicator.classList.remove('hidden'); btnRecord.classList.add('hidden');
    } catch (err) {
        if (err.name === 'NotAllowedError') {
            showToast('麦克风权限被拦截，请在地址栏允许麦克风后刷新页面', 'error');
        } else { alert('无法启动录音: ' + err.message); }
    }
}
function stopRecording() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop(); mediaRecorder.stream.getTracks().forEach(t => t.stop());
        if (recognition) recognition.stop();
        clearInterval(timerInterval);
        recordingIndicator.classList.add('hidden'); btnRecord.classList.remove('hidden');
    }
}
function updateTimer() {
    const e = Math.floor((Date.now() - startTime) / 1000);
    recordDuration.textContent = `${String(Math.floor(e/60)).padStart(2,'0')}:${String(e%60).padStart(2,'0')}`;
}

btnRecord.addEventListener('click', startRecording);
btnStopRecord.addEventListener('click', stopRecording);
btnFillDemo.addEventListener('click', () => {
    transcriptInput.value = `（原始转写 - 包含口语化错误）：\n${rawImperfectTranscript}`;
    btnSmartFix.classList.remove('hidden');
    wordCountText.textContent = `当前内容长度：${transcriptInput.value.length} 字 | 建议 30,000 字以内`;
});
btnFillEnDemo.addEventListener('click', () => {
    setLanguage('en');
    transcriptInput.value = `(Raw transcript – casual speech, filler words included):\n${englishDemoTranscript}`;
    btnSmartFix.classList.remove('hidden');
    wordCountText.textContent = `Current length: ${transcriptInput.value.length} chars | Recommended < 30,000`;
});
btnFillLongDemo.addEventListener('click', () => {
    transcriptInput.value = `（模拟长会议）：\n${longMeetingDemoTranscript}`;
    btnSmartFix.classList.remove('hidden');
    wordCountText.textContent = `当前内容长度：${transcriptInput.value.length} 字 | 建议 30,000 字以内`;
});

btnSmartFix.addEventListener('click', async () => {
    const transcript = transcriptInput.value.trim();
    if (!transcript) return;
    btnSmartFix.disabled = true;
    btnSmartFix.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i> AI 降噪整理中...';
    try {
        const data = await callAPI('/api/fix', { transcript });
        transcriptInput.value = `（AI 已智能降噪、纠错并分段）：\n${data.result}`;
        btnSmartFix.classList.add('hidden');
    } catch { showToast('AI 修正失败，请检查 API Key 是否正确', 'error'); }
    finally {
        btnSmartFix.disabled = false;
        btnSmartFix.innerHTML = '<i class="fas fa-wand-sparkles mr-1"></i> AI 降噪整理';
    }
});

btnQuickDemo.addEventListener('click', async () => {
    document.getElementById('demo').scrollIntoView({ behavior: 'smooth' });
    await sleep(800); btnFillDemo.click();
    await sleep(1000); btnSmartFix.click();
    await sleep(2500); btnAnalyze.click();
});

btnAnalyze.addEventListener('click', async () => {
    const transcript = transcriptInput.value.trim();
    if (!transcript) { alert('请先输入或填充转录文本！'); return; }
    const isLong = transcript.length > 5000;
    if (transcript.length > 25000 && !confirm('内容超过 2.5 万字，AI 深度分析耗时较长，是否继续？')) return;

    setLoading(btnAnalyze, isLong ? '正在长会议深度建模...' : 'AI 智能分析中...', true);
    outputZone.classList.remove('visible');

    try {
        const data = await callAPI('/api/analyze', { transcript });
        let result;
        try { result = JSON.parse(data.result); }
        catch { result = JSON.parse(data.result.replace(/```json|```/g, '').trim()); }
        lastAnalysisResult = result;
        renderMeetingResult(result);
        outputZone.classList.add('visible');
        outputZone.scrollIntoView({ behavior: 'smooth', block: 'start' });
        showToast('分析完成！可点击「发送到看板」跟进行动项', 'success');
    } catch (err) {
        console.error(err);
        showToast('AI 分析失败，请检查 API Key 是否正确', 'error');
    } finally { setLoading(btnAnalyze, '<i class="fas fa-brain mr-2"></i> 开始 AI 智能分析', false); }
});

function renderMeetingResult(data) {
    summaryContent.textContent = data.summary;
    decisionsList.innerHTML = (data.decisions || []).map(d => `
        <li class="flex items-start space-x-3 text-sm text-gray-700">
            <i class="fas fa-check-circle text-blue-500 mt-1 flex-shrink-0"></i><span>${d}</span>
        </li>`).join('');
    actionsTableBody.innerHTML = (data.actions || []).map(a => `
        <tr class="hover:bg-gray-50 transition">
            <td class="px-4 py-3 text-sm font-medium text-gray-900">${a.title}</td>
            <td class="px-4 py-3 text-sm text-gray-500">${a.owner}</td>
            <td class="px-4 py-3 text-sm text-gray-400">${a.dueDate || '—'}</td>
            <td class="px-4 py-3 text-sm">
                <span class="px-2 py-1 rounded-full text-xs font-bold badge-${(a.priority||'p2').toLowerCase()}">${a.priority}</span>
            </td>
        </tr>`).join('');
}

btnCopyMD.addEventListener('click', () => {
    if (!lastAnalysisResult) return;
    const md = `# 会议纪要\n## 核心摘要\n${lastAnalysisResult.summary}\n## 关键决策\n${(lastAnalysisResult.decisions||[]).map(d=>`- ${d}`).join('\n')}\n## 行动项\n| 事项 | 负责人 | 截止 | 优先级 |\n| --- | --- | --- | --- |\n${(lastAnalysisResult.actions||[]).map(a=>`| ${a.title} | ${a.owner} | ${a.dueDate||'—'} | ${a.priority} |`).join('\n')}`;
    navigator.clipboard.writeText(md).then(() => showToast('已复制 Markdown', 'success'));
});
btnDownloadCSV.addEventListener('click', () => {
    if (!lastAnalysisResult) return;
    let csv = '\uFEFF事项,负责人,截止日期,优先级\n';
    (lastAnalysisResult.actions||[]).forEach(a => { csv += `"${a.title}","${a.owner}","${a.dueDate||''}","${a.priority}"\n`; });
    dlFile(csv, '行动项清单.csv', 'text/csv;charset=utf-8;');
});
btnSendToTracker.addEventListener('click', () => {
    if (!lastAnalysisResult || !lastAnalysisResult.actions || !lastAnalysisResult.actions.length) {
        showToast('请先完成会议分析', 'error'); return;
    }
    lastAnalysisResult.actions.forEach(a => addToKanban(a.title, a.owner, a.priority, 'todo'));
    switchTab('tab-tracker');
    showToast(`已发送 ${lastAnalysisResult.actions.length} 个行动项到看板`, 'success');
});

// ──────────────────────────────────────────────
// 2. 周报生成模块
// ──────────────────────────────────────────────
const weeklyDemoText = `周一：参加了产品需求评审会，确定了用户中心页面改版方案，决定采用新的卡片式布局，张明负责原型稿，周四前完成。
周二：完成了商品详情页的前端开发，已提交代码评审，等待李华合并。和运营对接了大促活动页的需求，发现和技术侧有冲突，暂时搁置等下周三对齐会。
周三：参加了Q2复盘会，整体GMV完成率87%，主要卡点是支付转化率低，下周要重点优化。下午修了3个线上bug，其中一个是高优先级的登录失效问题。
周四：参加了跨部门对齐会，最终确认大促和会员体系并行，技术排期确认了下周五出方案。完成了数据埋点文档的编写。
周五：整理了本周会议纪要，跟进了上周的两个行动项（购物车优化已上线，支付页改版还在进行中）。准备了下周的工作计划。`;

document.getElementById('btnFillWeeklyDemo').addEventListener('click', () => {
    document.getElementById('weeklyInput').value = weeklyDemoText;
});

document.getElementById('btnGenerateWeekly').addEventListener('click', async () => {
    const input = document.getElementById('weeklyInput').value.trim();
    if (!input) { alert('请先输入本周工作内容！'); return; }
    const role = document.getElementById('weeklyRole').value || '职场人';
    const style = document.getElementById('weeklyStyle').value;

    const btn = document.getElementById('btnGenerateWeekly');
    setLoading(btn, '周报生成中...', true);

    try {
        const data = await callAPI('/api/weekly', { input, role, style });
        const weeklyOutput = document.getElementById('weeklyOutput');
        document.getElementById('weeklyResult').textContent = data.result;
        weeklyOutput.classList.remove('opacity-0', 'translate-y-4', 'pointer-events-none');
        weeklyOutput.classList.add('opacity-100');
        weeklyOutput.scrollIntoView({ behavior: 'smooth', block: 'start' });
        showToast('周报生成成功！', 'success');
    } catch { showToast('周报生成失败，请检查 API Key 是否正确', 'error'); }
    finally { setLoading(btn, '<i class="fas fa-wand-sparkles mr-2"></i> 一键生成周报', false); }
});

document.getElementById('btnCopyWeekly').addEventListener('click', () => {
    const text = document.getElementById('weeklyResult').textContent;
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => showToast('已复制周报', 'success'));
});

// ──────────────────────────────────────────────
// 3. 需求对齐模块
// ──────────────────────────────────────────────
const alignDemo = {
    p1: '运营部门诉求：5月大促活动GMV要同比提升30%，需要上线满减优惠券功能、大促活动落地页，以及商品限时秒杀功能，最晚4月25日必须上线。',
    p2: '产品部门诉求：Q2核心OKR是会员体系上线，包含积分系统、等级体系、专属权益页，预计需要3-4周开发时间，这是年度重点项目，不能延期。',
    p3: '技术部门诉求：5月大促期间系统压力大，技术团队需要全力保障稳定性，大促前两周只做Bug修复，不接收任何新功能需求，同时还有架构升级计划要在5月中旬执行。'
};
document.getElementById('btnFillAlignDemo').addEventListener('click', () => {
    document.getElementById('alignInput1').value = alignDemo.p1;
    document.getElementById('alignInput2').value = alignDemo.p2;
    document.getElementById('alignInput3').value = alignDemo.p3;
});

document.getElementById('btnGenerateAlign').addEventListener('click', async () => {
    const p1 = document.getElementById('alignInput1').value.trim();
    const p2 = document.getElementById('alignInput2').value.trim();
    const p3 = document.getElementById('alignInput3').value.trim();
    if (!p1 && !p2) { alert('请至少填写两方的需求！'); return; }

    const btn = document.getElementById('btnGenerateAlign');
    setLoading(btn, '需求对齐分析中...', true);

    try {
        const data = await callAPI('/api/align', { p1, p2, p3 });
        const alignOutput = document.getElementById('alignOutput');
        document.getElementById('alignResult').textContent = data.result;
        alignOutput.classList.remove('opacity-0', 'translate-y-4', 'pointer-events-none');
        alignOutput.classList.add('opacity-100');
        alignOutput.scrollIntoView({ behavior: 'smooth', block: 'start' });
        showToast('对齐报告已生成！', 'success');
    } catch { showToast('对齐报告生成失败，请检查 API Key 是否正确', 'error'); }
    finally { setLoading(btn, '<i class="fas fa-balance-scale mr-2"></i> 生成对齐报告', false); }
});

document.getElementById('btnCopyAlign').addEventListener('click', () => {
    const text = document.getElementById('alignResult').textContent;
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => showToast('已复制对齐报告', 'success'));
});

// ──────────────────────────────────────────────
// 4. 行动项看板模块
// ──────────────────────────────────────────────
let kanbanItems = [];
let kanbanIdCounter = 1;

function addToKanban(title, owner, priority, status = 'todo') {
    const id = 'k' + (kanbanIdCounter++);
    kanbanItems.push({ id, title, owner: owner || '待分配', priority: priority || 'P2', status });
    renderKanban();
}

function renderKanban() {
    const cols = { todo: [], doing: [], done: [] };
    kanbanItems.forEach(item => { if (cols[item.status]) cols[item.status].push(item); });

    ['todo', 'doing', 'done'].forEach(col => {
        const el = document.getElementById('kanban-' + col);
        const count = document.getElementById('count-' + col);
        el.innerHTML = cols[col].map(item => `
            <div class="kanban-card bg-white rounded-xl p-3 shadow-sm border border-gray-100 hover:shadow-md transition" id="card-${item.id}">
                <div class="flex justify-between items-start mb-2">
                    <span class="text-sm font-semibold text-gray-800 leading-snug flex-1 mr-2">${item.title}</span>
                    <span class="px-1.5 py-0.5 rounded text-[10px] font-bold flex-shrink-0 badge-${item.priority.toLowerCase()}">${item.priority}</span>
                </div>
                <div class="flex items-center justify-between">
                    <span class="text-xs text-gray-400"><i class="fas fa-user mr-1"></i>${item.owner}</span>
                    <div class="flex gap-1">
                        ${col !== 'todo' ? `<button onclick="moveKanban('${item.id}','prev')" class="text-[10px] text-gray-400 hover:text-blue-500 px-1.5 py-0.5 rounded bg-gray-50"><i class="fas fa-arrow-left"></i></button>` : ''}
                        ${col !== 'done' ? `<button onclick="moveKanban('${item.id}','next')" class="text-[10px] text-gray-400 hover:text-emerald-500 px-1.5 py-0.5 rounded bg-gray-50"><i class="fas fa-arrow-right"></i></button>` : ''}
                        <button onclick="removeKanban('${item.id}')" class="text-[10px] text-gray-400 hover:text-red-500 px-1.5 py-0.5 rounded bg-gray-50"><i class="fas fa-times"></i></button>
                    </div>
                </div>
            </div>`).join('');
        count.textContent = cols[col].length;
    });

    document.getElementById('trackerEmpty').style.display = kanbanItems.length === 0 ? 'block' : 'none';
}

window.moveKanban = function(id, dir) {
    const order = ['todo', 'doing', 'done'];
    const item = kanbanItems.find(i => i.id === id);
    if (!item) return;
    const idx = order.indexOf(item.status);
    if (dir === 'next' && idx < 2) item.status = order[idx + 1];
    if (dir === 'prev' && idx > 0) item.status = order[idx - 1];
    renderKanban();
};
window.removeKanban = function(id) {
    kanbanItems = kanbanItems.filter(i => i.id !== id);
    renderKanban();
};

document.getElementById('btnClearTracker').addEventListener('click', () => {
    if (kanbanItems.length === 0) return;
    if (confirm('确定清空所有行动项？')) { kanbanItems = []; renderKanban(); }
});

document.getElementById('btnAddAction').addEventListener('click', () => {
    const title = prompt('行动项内容：');
    if (!title) return;
    const owner = prompt('负责人（可留空）：') || '待分配';
    addToKanban(title, owner, 'P2', 'todo');
    showToast('已添加行动项', 'success');
});

// ──────────────────────────────────────────────
// 工具函数
// ──────────────────────────────────────────────
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function setLoading(btn, text, loading) {
    btn.disabled = loading;
    btn.innerHTML = loading ? `<i class="fas fa-spinner fa-spin mr-2"></i>${text}` : text;
}

function dlFile(content, filename, mimeType) {
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([content], { type: mimeType }));
    link.download = filename; link.click();
}

function showToast(msg, type = 'success') {
    const toast = document.createElement('div');
    const color = type === 'success' ? 'bg-emerald-600' : 'bg-red-600';
    toast.className = `fixed bottom-8 left-1/2 -translate-x-1/2 ${color} text-white px-6 py-3 rounded-xl shadow-2xl z-[200] text-sm font-semibold transition-all duration-300`;
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 300); }, 2500);
}

// ──────────────────────────────────────────────
// CSS 注入（Tab 样式）
// ──────────────────────────────────────────────
const style = document.createElement('style');
style.textContent = `
.active-tab { background: #2563eb; color: #fff; box-shadow: 0 4px 15px rgba(37,99,235,0.3); }
.inactive-tab { background: #fff; color: #6b7280; border: 1px solid #e5e7eb; }
.inactive-tab:hover { background: #f0f9ff; color: #2563eb; border-color: #bfdbfe; }
`;
document.head.appendChild(style);

// ──────────────────────────────────────────────
// 初始化
// ──────────────────────────────────────────────
renderKanban();
updateNavApiKeyBadge();
