import http.server
import socketserver
import json
import urllib.request
import urllib.error
import os
import time
import base64
import tempfile
import threading

PORT = 8001
ENV_FILE = '.env'

def get_env():
    env = {}
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE, 'r') as f:
            for line in f:
                if '=' in line:
                    k, v = line.split('=', 1)
                    env[k.strip()] = v.strip()
    return env

ENV = get_env()
ZHIPU_KEY = ENV.get('ZHIPU_API_KEY')
ALIYUN_KEY = ENV.get('ALIYUN_API_KEY')

# API Endpoints
ZHIPU_URL = 'https://open.bigmodel.cn/api/paas/v4/chat/completions'
# 阿里云百炼 Paraformer 录音文件识别接口（异步）
ALIYUN_ASR_SUBMIT = 'https://dashscope.aliyuncs.com/api/v1/services/audio/asr/transcription'
ALIYUN_TASK_QUERY = 'https://dashscope.aliyuncs.com/api/v1/tasks/{task_id}'

# 临时文件托管目录（用于本地 HTTP 托管音频）
TEMP_AUDIO_DIR = os.path.join(tempfile.gettempdir(), 'huisheng_asr')
os.makedirs(TEMP_AUDIO_DIR, exist_ok=True)

def upload_audio_to_dashscope_oss(audio_bytes, filename, api_key):
    """
    调用阿里云百炼的文件上传接口，将音频上传到百炼托管存储，返回可被 ASR 使用的 URL。
    接口文档：https://help.aliyun.com/zh/model-studio/upload-file-api
    """
    # 1. 申请上传凭证
    policy_url = 'https://dashscope.aliyuncs.com/api/v1/uploads'
    policy_payload = json.dumps({"filename": filename}).encode('utf-8')
    policy_req = urllib.request.Request(policy_url, data=policy_payload, method='POST')
    policy_req.add_header('Authorization', f'Bearer {api_key}')
    policy_req.add_header('Content-Type', 'application/json')
    
    with urllib.request.urlopen(policy_req, timeout=30) as resp:
        policy_res = json.loads(resp.read().decode('utf-8'))
    
    upload_url = policy_res['output']['upload_url']
    file_id = policy_res['output']['file_id']
    oss_header = policy_res['output'].get('oss_headers', {})

    # 2. 直接 PUT 上传到 OSS
    put_req = urllib.request.Request(upload_url, data=audio_bytes, method='PUT')
    for k, v in oss_header.items():
        put_req.add_header(k, v)
    # 根据文件名判断 Content-Type
    ext = filename.rsplit('.', 1)[-1].lower()
    ct_map = {'m4a': 'audio/mp4', 'mp3': 'audio/mpeg', 'wav': 'audio/wav',
              'ogg': 'audio/ogg', 'flac': 'audio/flac', 'aac': 'audio/aac', 'webm': 'audio/webm'}
    put_req.add_header('Content-Type', ct_map.get(ext, 'audio/mpeg'))
    with urllib.request.urlopen(put_req, timeout=120) as put_resp:
        pass  # 成功则无内容

    # 3. 返回可用于 ASR 的 file_id 格式 URL
    # 百炼 ASR 支持 fileid://xxx 格式
    return f'fileid://{file_id}'


class MyHandler(http.server.SimpleHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)

        if self.path == '/api/analyze' or self.path == '/api/fix':
            self.handle_zhipu_ai(post_data, 'fix' if 'fix' in self.path else 'analyze')
        elif self.path == '/api/asr':
            self.handle_aliyun_asr(post_data)
        else:
            self.send_response(404)
            self.end_headers()

    def handle_aliyun_asr(self, post_data):
        """调用阿里云百炼 ASR 进行语音转文字（支持中英文）"""
        if not ALIYUN_KEY:
            self.send_error_res("未在 .env 中找到 ALIYUN_API_KEY")
            return

        try:
            user_request = json.loads(post_data)
            audio_data = user_request.get('audio_data', '')
            language = user_request.get('language', 'zh')

            if not audio_data:
                self.send_error_res("未提供音频数据")
                return

            audio_bytes = base64.b64decode(audio_data)
            filename = f"recording_{int(time.time())}.m4a"

            audio_url = upload_audio_to_dashscope_oss(audio_bytes, filename, ALIYUN_KEY)

            submit_payload = {
                "model": "paraformer-v2",
                "input": {
                    "file_urls": [audio_url]
                },
                "parameters": {
                    "language_hints": ["en", "zh"] if language == 'auto' else [language]
                }
            }

            submit_req = urllib.request.Request(ALIYUN_ASR_SUBMIT, data=json.dumps(submit_payload).encode('utf-8'), method='POST')
            submit_req.add_header('Content-Type', 'application/json')
            submit_req.add_header('Authorization', f'Bearer {ALIYUN_KEY}')

            with urllib.request.urlopen(submit_req, timeout=30) as submit_resp:
                submit_res = json.loads(submit_resp.read().decode('utf-8'))
                task_id = submit_res['output']['task_id']

            max_retries = 60
            retry_interval = 2
            transcript_text = ""

            for attempt in range(max_retries):
                time.sleep(retry_interval)
                query_url = ALIYUN_TASK_QUERY.format(task_id=task_id)
                query_req = urllib.request.Request(query_url, method='GET')
                query_req.add_header('Authorization', f'Bearer {ALIYUN_KEY}')

                with urllib.request.urlopen(query_req, timeout=30) as query_resp:
                    query_res = json.loads(query_resp.read().decode('utf-8'))
                    task_status = query_res['output']['task_status']

                    if task_status == 'SUCCEEDED':
                        transcript_text = query_res['output']['results'][0]['transcription_text']
                        break
                    elif task_status == 'FAILED':
                        error_msg = query_res['output'].get('code', 'Unknown error')
                        self.send_error_res(f"ASR 任务失败: {error_msg}")
                        return

            if not transcript_text:
                self.send_error_res("ASR 任务超时")
                return

            self.send_json_res({"result": transcript_text})

        except Exception as e:
            self.send_error_res(f"ASR 处理错误: {str(e)}")

    def handle_zhipu_ai(self, post_data, type):
        """调用智谱 GLM-4 进行分析（支持中英文）"""
        if not ZHIPU_KEY:
            self.send_error_res("未在 .env 中找到 ZHIPU_API_KEY")
            return

        user_request = json.loads(post_data)
        transcript = user_request.get('transcript', '')
        language = user_request.get('language', 'zh')

        if type == 'fix':
            if language == 'en':
                system_prompt = """You are a professional meeting transcription optimization expert. You receive raw, messy ASR (speech-to-text) text without speaker labels.

Your task is to transform this "text swamp" into clear, readable, and structured text:
1. **Smart Noise Reduction**: Thoroughly remove conversational filler words (like: um, uh, like, you know, etc.).
2. **Speaker Identification**: Insert [Speaker Name] at appropriate positions based on context clues (such as someone introducing themselves, being addressed by others, or inferred from discussion content).
3. **Logical Segmentation**: Segment the text based on topic changes.
4. **Information Compression**: Make the text more concise while preserving all facts.

Output the optimized text directly, without any opening remarks."""
            else:
                system_prompt = """你是一个专业的会议速记优化专家。你收到的是一段原始、凌乱、没有任何说话人标签的 ASR（语音转文字）文本。

你的任务是将这段"文字泥潭"转化为清晰、易读且结构化的文本：
1. **智能降噪**：彻底删除口语化废话（如：那个、然后、嗯、啊、就是等）。
2. **说话人识别 (Speaker Identification)**：通过上下文语境（如：某人自报姓名、被他人称呼、或根据讨论内容推断）在合适的位置插入[说话人姓名]。
3. **逻辑分段**：根据话题变化进行分段。
4. **信息压缩**：在保持所有事实的前提下，使文本更精炼。

直接输出优化后的文本，不要包含任何开场白。"""
            response_format = None
        else:
            if language == 'en':
                system_prompt = """You are a top-tier meeting strategic analysis officer. You are processing a raw, speaker-unlabeled long meeting transcript.

### Core Tasks:
1. **Penetrate Fluff**: Filter out 90% of redundant information from tens of thousands of words of raw stream.
2. **Infer Attribution**: Even without explicit labels, accurately infer the attribution of decisions and tasks through context (such as "Wang Fang, you're responsible for..." or "I, Li Hua, think...").
3. **Global Aggregation**: Compare the entire text to extract the final "consensus conclusions".

### Output Format Requirements (JSON):
{
  "summary": "One-sentence core conclusion + 3 key points",
  "decisions": [
    "Decision point (must include conclusion and background)"
  ],
  "actions": [
    {
      "title": "Specific action item",
      "owner": "Owner's name (inferred from context, mark as 'TBD' if truly uncertain)",
      "dueDate": "Deadline (mark as 'Ongoing' if none)",
      "priority": "P0/P1/P2"
    }
  ]
}

Output only the pure JSON string, strictly prohibit including Markdown code block markers."""
            else:
                system_prompt = """你是一个顶级的会议战略分析官。你正在处理一段原始、无说话人标签的长会议转录。

### 核心任务：
1. **穿透废话**：从数万字的原始流中过滤 90% 的冗余信息。
2. **推断归属**：即使没有明确标签，也要通过上下文（如"王芳你负责..."或"我李华觉得..."）精准推断出决策和任务的归属人。
3. **全局聚合**：对比全篇，提取最终达成的"共识结论"。

### 输出格式要求 (JSON)：
{
  "summary": "一句话核心结论 + 3个关键点",
  "decisions": [
    "决策点（必须包含结论及背景）"
  ],
  "actions": [
    {
      "title": "具体的行动事项",
      "owner": "负责人姓名（通过语境推断，若实在无法确定则标'待定'）",
      "dueDate": "截止日期（若无则标'持续'）",
      "priority": "P0/P1/P2"
    }
  ]
}

只输出纯 JSON 字符串，严禁包含 Markdown 代码块标记。"""
            response_format = {"type": "json_object"}

        api_payload = {
            "model": "glm-4",
            "messages": [{"role": "system", "content": system_prompt}, {"role": "user", "content": transcript}],
            "temperature": 0.1,
            "max_tokens": 4095
        }
        if response_format: api_payload["response_format"] = response_format

        req = urllib.request.Request(ZHIPU_URL, data=json.dumps(api_payload).encode('utf-8'))
        req.add_header('Content-Type', 'application/json')
        req.add_header('Authorization', f'Bearer {ZHIPU_KEY}')

        try:
            with urllib.request.urlopen(req) as response:
                api_res = json.loads(response.read().decode('utf-8'))
                content = api_res['choices'][0]['message']['content']
                self.send_json_res({"result": content})
        except Exception as e:
            self.send_error_res(str(e))

    def send_json_res(self, data):
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))

    def send_error_res(self, msg):
        self.send_response(500)
        self.end_headers()
        self.wfile.write(json.dumps({"error": msg}).encode('utf-8'))

    def do_GET(self):
        return http.server.SimpleHTTPRequestHandler.do_GET(self)

if __name__ == "__main__":
    print("Main block reached...")
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), MyHandler) as httpd:
        print(f"Serving at port {PORT} [Zhipu GLM-4 + Aliyun ASR]")
        httpd.serve_forever()
