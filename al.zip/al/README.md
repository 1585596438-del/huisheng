# 会声 HuiSheng — 产品 Demo（静态前端）

这个 Demo 用于把 `project-intro-optimized.md` 里的产品内容"产品化呈现"，方便你录屏/演示：
- Landing：价值主张、痛点、功能、流程
- 体验区：录音上传 / 文本粘贴（前端模拟）
- 输出区：摘要 / 决策 / 行动项表格
- 一键导出：Markdown / CSV / JSON

---

## ⚡ 快速启动（收到文件的人看这里）

### 前置要求
- 安装 [Node.js](https://nodejs.org)（推荐 LTS 版本，一路下一步即可）
- （可选）申请 [阿里云百炼 API Key](https://bailian.console.aliyun.com)，用于真实 AI 功能

### Windows 用户
双击运行 `start_server.bat`，按提示输入 API Key，然后浏览器打开 http://localhost:8000

### macOS / Linux 用户
```bash
chmod +x start_server.sh
./start_server.sh
```
按提示输入 API Key，然后浏览器打开 http://localhost:8000

### 不想用 API Key？
直接启动也可以，页面会以**模拟数据模式**运行，所有 AI 输出为预设示例，适合演示。

---

## 1) 如何运行（详细）

### 方式 A：Node（推荐，可接入真实 API）
```bash
# Windows PowerShell
$env:DASHSCOPE_API_KEY="你的Key"
node server.js

# macOS / Linux
export DASHSCOPE_API_KEY="你的Key"
node server.js
```
然后打开：`http://localhost:8000`

> 说明：本 Demo 的 LLM 接口使用百炼 OpenAI 兼容模式：  
> `base_url=https://dashscope.aliyuncs.com/compatible-mode/v1`

### 方式 B：Python（仅静态页面，无真实 AI）
```bash
python3 -m http.server 8000
```
然后打开：`http://localhost:8000`  
（注意：Python 方式无法调用后端 `/api/analyze`，会自动回退为"模拟输出"。）

### 方式 C：VS Code Live Server
右键 `index.html` → Open with Live Server（仅静态页面）

---

## 2) 如何替换为"真实可用"的版本（接 API）

你只需要在 `app.js` 里替换这段逻辑：
- `fakeGenerateFromTranscript(transcript)`（模拟结构化输出）

替换为真实链路：
1. **ASR（可选）**：录音 → 文字  
2. **LLM**：把文字喂给模型，要求输出固定 JSON schema  
3. **渲染**：把 JSON 渲染到摘要/决策/行动项表格  

### 关于"直接录音"
页面支持浏览器直接录音（MediaRecorder）：
- 需要麦克风权限
- 建议在 `localhost` 打开（浏览器一般允许）
- 目前 Demo 默认仍以"转写文本"为输入，若要真实可用需接入 ASR

建议 schema（与页面展示保持一致）：
```json
{
  "summary": "string",
  "decisions": ["string"],
  "actions": [
    { "title": "string", "owner": "string", "dueDate": "string", "priority": "P0|P1|P2" }
  ]
}
```

---

## 3) Demo 录屏建议（30 秒路径）
1) 打开页面 → 点击「填充演示文本」  
2) 点击「生成摘要/行动项」  
3) 展示行动项表格 → 点击「下载 .csv」或「复制 Markdown」  
