const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 8000;
const API_KEY = process.env.DASHSCOPE_API_KEY || '';
const API_URL = 'dashscope.aliyuncs.com';

// 启动时检查 API Key
if (!API_KEY) {
    console.warn('⚠️  警告：未检测到 DASHSCOPE_API_KEY 环境变量！');
    console.warn('   AI 功能将不可用，页面仅展示模拟数据。');
    console.warn('   设置方法：');
    console.warn('   Windows PowerShell: $env:DASHSCOPE_API_KEY="你的Key"');
    console.warn('   macOS / Linux:      export DASHSCOPE_API_KEY="你的Key"');
    console.warn('   然后重新运行 node server.js');
    console.warn('');
}
const API_PATH = '/compatible-mode/v1/chat/completions';

const MIME_TYPES = {
    '.html': 'text/html',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.wav': 'audio/wav',
    '.mp4': 'video/mp4',
    '.woff': 'application/font-woff',
    '.ttf': 'application/font-ttf',
    '.eot': 'application/vnd.ms-fontobject',
    '.otf': 'application/font-otf',
    '.wasm': 'application/wasm'
};

const server = http.createServer((req, res) => {
    console.log(`${req.method} ${req.url}`);

    // Handle API Requests
    if (req.url === '/api/analyze' && req.method === 'POST') {
        handleProxy(req, res, 'analyze');
        return;
    }
    if (req.url === '/api/fix' && req.method === 'POST') {
        handleProxy(req, res, 'fix');
        return;
    }
    if (req.url === '/api/weekly' && req.method === 'POST') {
        handleProxy(req, res, 'weekly');
        return;
    }
    if (req.url === '/api/align' && req.method === 'POST') {
        handleProxy(req, res, 'align');
        return;
    }

    // Handle Static Files
    let filePath = '.' + req.url;
    if (filePath === './') {
        filePath = './index.html';
    }

    const extname = String(path.extname(filePath)).toLowerCase();
    const contentType = MIME_TYPES[extname] || 'application/octet-stream';

    fs.readFile(filePath, (error, content) => {
        if (error) {
            if (error.code === 'ENOENT') {
                fs.readFile('./404.html', (err, data) => {
                    res.writeHead(404, { 'Content-Type': 'text/html' });
                    res.end(data || '404 Not Found', 'utf-8');
                });
            } else {
                res.writeHead(500);
                res.end(`Server Error: ${error.code}`);
            }
        } else {
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(content, 'utf-8');
        }
    });
});

function handleProxy(req, res, type) {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
        const userRequest = JSON.parse(body);
        const transcript = userRequest.transcript;

        let systemPrompt = '';
        let userPrompt = transcript;

        if (type === 'fix') {
            systemPrompt = '你是一个会议纪要整理专家。请将以下凌乱的 ASR 转写文本进行修正：纠正同音字错误、添加标点符号、识别并标注说话人（如果可以推断）、去除冗余语气词。保持原意不变，使文本专业、易读。直接输出修正后的文本。';
        } else if (type === 'weekly') {
            const role = userRequest.role || '职场人';
            const styleMap = {
                concise: '简洁专业风格，重点突出，避免废话，适合汇报给直接上级',
                detailed: '数据详实风格，尽量量化成果，适合汇报给大领导',
                team: '轻松协作风格，说清楚在哪里帮到了团队、哪里需要支持'
            };
            const styleDesc = styleMap[userRequest.style] || styleMap.concise;
            systemPrompt = `你是一个职场效率专家，擅长将碎片化的工作记录整理成专业的工作周报。
请根据用户提供的本周工作流水账，生成一份结构清晰的工作周报。
岗位：${role}
汇报风格：${styleDesc}

周报格式要求（严格遵守）：
【本周完成事项】
- 用 1-2 句话描述每项完成工作，突出结果和价值

【本周关键决策 / 推进项目】
- 列出重要决策和项目推进情况

【下周工作计划】
- 具体可执行的计划，3-5 条

【本周遇到的问题/风险】
- 客观描述阻碍或风险，必要时附带解决思路

请直接输出周报正文，不要加任何前言解释。`;
            userPrompt = userRequest.input;
        } else if (type === 'align') {
            systemPrompt = `你是一个专业的跨部门需求对齐顾问，擅长识别各方诉求的冲突点并给出务实的共识方案。
请根据用户提供的各方需求描述，生成一份结构化的需求对齐报告。

报告格式（严格遵守）：

━━━━━━━━━━━━━━━━━━━━━━
【需求对齐报告】
━━━━━━━━━━━━━━━━━━━━━━

▶ 各方核心诉求
  · 第一方：[一句话总结核心目标]
  · 第二方：[一句话总结核心目标]
  · 第三方：[一句话总结核心目标，如有]

▶ 冲突分析
  ⚠️ 冲突1：[冲突描述及根本原因]
  ⚠️ 冲突2：[如有]

▶ 共识基础
  ✅ [各方都能接受的共同点]

▶ 建议方案
  【方案A】[推荐方案，说明理由]
  【方案B】[备选方案]
  【方案C】[如有]

▶ 下一步行动
  · [具体行动项，含负责人和时间节点]

━━━━━━━━━━━━━━━━━━━━━━

请直接输出报告内容，语言简洁务实。`;
            const parts = [];
            if (userRequest.p1) parts.push(`第一方需求：${userRequest.p1}`);
            if (userRequest.p2) parts.push(`第二方需求：${userRequest.p2}`);
            if (userRequest.p3) parts.push(`第三方需求：${userRequest.p3}`);
            userPrompt = parts.join('\n\n');
        } else {
            systemPrompt = `你是一个会议效率专家。请根据提供的会议转录文本，输出 JSON 格式的分析结果。
格式要求：
{
  "summary": "简洁的会议摘要",
  "decisions": ["决策点1", "决策点2"],
  "actions": [
    {"title": "任务内容", "owner": "负责人", "dueDate": "截止日期", "priority": "P0/P1/P2"}
  ]
}
只输出 JSON 内容，不要包含 Markdown 代码块。`;
        }

        const postData = JSON.stringify({
            model: "qwen-plus",
            messages: [
                { role: "system", content: systemPrompt },
                { role: "user", content: userPrompt }
            ],
            response_format: type === 'analyze' ? { type: "json_object" } : undefined
        });

        const options = {
            hostname: API_URL,
            path: API_PATH,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`,
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        const proxyReq = https.request(options, (proxyRes) => {
            let responseData = '';
            proxyRes.on('data', (d) => { responseData += d; });
            proxyRes.on('end', () => {
                const apiResult = JSON.parse(responseData);
                const content = apiResult.choices[0].message.content;
                
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ result: content }));
            });
        });

        proxyReq.on('error', (e) => {
            console.error(e);
            res.writeHead(500);
            res.end(JSON.stringify({ error: 'API Call Failed' }));
        });

        proxyReq.write(postData);
        proxyReq.end();
    });
}

server.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}/`);
});
