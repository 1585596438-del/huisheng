@echo off
chcp 65001 >nul
echo ============================================
echo   会声 HuiSheng — 本地启动脚本
echo ============================================
echo.

:: 检查 Node.js 是否安装
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未找到 Node.js，请先安装：https://nodejs.org
    pause
    exit /b 1
)

:: 如果已在环境变量中设置了 Key，直接使用
if defined DASHSCOPE_API_KEY (
    echo [✓] 已检测到 DASHSCOPE_API_KEY 环境变量
    goto :start
)

:: 否则提示用户输入
echo 请输入你的百炼 API Key（获取地址：https://bailian.console.aliyun.com）
echo 如果暂时没有，直接回车跳过（将使用模拟数据模式）
echo.
set /p USER_KEY="API Key: "

if not "%USER_KEY%"=="" (
    set DASHSCOPE_API_KEY=%USER_KEY%
    echo [✓] API Key 已设置（仅本次有效）
) else (
    echo [!] 未设置 API Key，将以模拟模式运行
)

:start
echo.
echo [启动中] node server.js ...
echo [提示] 打开浏览器访问 http://localhost:8000
echo [提示] 按 Ctrl+C 停止服务
echo.
node server.js
pause
